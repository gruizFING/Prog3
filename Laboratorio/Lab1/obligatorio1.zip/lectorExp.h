/*lectorExp.h*/

#ifndef _LECTOREXP_
#define _LECTOREXP_

#include "abexp.h"

/* Pre: "expr" debe ser un string sin caracteres en blanco (los
   definidos por la funcion isspace en ctype.h)*/
/* - Retorna un ABExp formado a partir de la expresion "expr".
   - Retorna true en error si la expresion ingresada no es una expresion valida
    (parentesis no balanceados, operadores consecutivos, falta de parametros de un operador).
*/
ABExp* leerExpr( const char* expr, bool &error);

#endif /*_LECTOREXP_*/

