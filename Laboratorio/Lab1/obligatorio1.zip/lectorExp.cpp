/*
  Programacion 3 - Curso 2010 - Facultad de Ingenieria (Udelar)
  Archivo: lectorExp.cpp
*/
#include "lectorExp.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/************Operaciones de Stack_Char*******************************************/
typedef struct Stack_Char{
	char* stack;
	int topestack;
	int size;
} Stack_Char;

Stack_Char* crear_Stack_Char(int size) {
	assert(size>0);
	Stack_Char* st = new Stack_Char;
	st->stack = new char[size];
	st->topestack = 0;// el tope apunta al elemento a agregar.
	st->size = size;

	return st;
}

void push(Stack_Char* st, char c) {
	assert(st!=NULL);
	assert(st->topestack<st->size);
	st->stack[st->topestack]=c;
	st->topestack++;
}

char top(Stack_Char* st) {
	assert(st!=NULL);
	assert(st->topestack>0);
	return st->stack[st->topestack-1];
}

void pop(Stack_Char* st) {
	assert(st!=NULL);
	assert(st->topestack>0);
	st->topestack--;
}

bool isempty(Stack_Char* st) {
	assert(st!=NULL);
	return (st->topestack<=0);
}

void destruir_Stack_Char(Stack_Char* st) {
	assert(st!=NULL);
	delete [] st->stack;
	delete st;
}
/**************************************************************************************/

/************Operaciones de Stack_AB*******************************************/
typedef struct Stack_AB {
	ABExp** stack;
	int topestack;
	int size;
} Stack_AB;

Stack_AB* crear_Stack_AB(int size) {
	assert(size>0);
	Stack_AB* st = new Stack_AB;
	st->stack = new ABExp*[size];
	st->topestack = 0;//el tope apunta al elemento a agregar.
	st->size = size;
	return st;
}

void push(Stack_AB* st, ABExp* ab) {
	assert(st!=NULL);
	assert(st->topestack<st->size);
	st->stack[st->topestack]=ab;
	st->topestack++;
}

ABExp* top(Stack_AB* st) {
	assert(st!=NULL);
	assert(st->topestack>0);
	return st->stack[st->topestack-1];
}

void pop(Stack_AB* st) {
	assert(st!=NULL);
	assert(st->topestack>0);
	st->topestack--;
}

bool isempty(Stack_AB* st) {
	assert(st!=NULL);
	return (st->topestack<=0);
}

void destruir_Stack_AB(Stack_AB* st) {
	assert(st!=NULL);
	delete [] st->stack;
	delete st;
}
/**************************************************************************************/

/* Pre: "expr" debe ser un string sin caracteres en blanco (los
   definidos por la funcion isspace en ctype.h)*/
ABExp* leerExpr( const char* expr, bool &error) {
	error = false;
	char* expr_b = strdup(expr);	
	if (strcmp(expr_b, "")==0) {
		error = true;
	}
	
	Stack_Char* st_char = crear_Stack_Char(200);
	Stack_AB*   st_ab   = crear_Stack_AB(200);

	ABExp* ab;
	double val;
	
	for (char* rec = expr_b; ((rec[0]!='\0')&&!error); ) {
		if (rec[0]=='(') {
			// extraer parentesis izq.
			push(st_char, rec[0]);
			rec++;
		} else if (rec[0]==')') {
			//se deben realizar las operaciones desde que abrio el '('
			while ((!isempty(st_char)) && (top(st_char)!='(')) {
				char op = top(st_char);
				pop(st_char);

				Oper operador = MAS;
				switch (op) {
					case '+':{
							 operador = MAS;
							 break;
						 };
					case '-':{
							 operador = MENOS;
							 break;
						 };
					case '*':{
							 operador = POR;
							 break;
						 };
					case '/':{
							 operador = DIV;
							 break;
						 };
					default:{
							error = true;
							break;
						};
				}

				// Saco los operandos del stack:
				if (isempty(st_ab)) {
					error=true;//El formato no es correcto, faltan operandos
				} else {
					ABExp* der = top(st_ab); pop(st_ab);
					if (isempty(st_ab)) {
						error=true;//El formato no es correcto, faltan operandos
					} else {
						ABExp* izq = top(st_ab); pop(st_ab);
						ab = crearABExpOper( operador, izq, der);
						//Coloco el resultado en el stack:
						push(st_ab, ab);
					}
				}
			}
			if (isempty(st_char))
				error = true;
			else
				pop(st_char);

			rec++;
		} else if ((rec[0]=='-')||(rec[0]=='+')) {
				// extraer MAS o MENOS
				if (isempty(st_char)) {
					push(st_char, rec[0]);
				} else {
					char t = top(st_char);
					switch (t) {
					case '(':{
						push(st_char, rec[0]);
						break;
					};
					case '+':{  /* Parse operador anterior */
						pop(st_char);
						Oper operador = MAS;
						if (isempty(st_ab)) {
							error=true;//Faltan operandos, el formato no es correcto.
						} else {
							ABExp* der = top(st_ab); pop(st_ab);
							if (isempty(st_ab)) {
								error=true;//Faltan operandos, el formato no es correcto.
							} else {
								ABExp* izq = top(st_ab); pop(st_ab);
								ab = crearABExpOper( operador, izq, der);
								// Coloco el resultado en el stack:
								push(st_ab, ab);
							}
						}

						push(st_char, rec[0]);
						break;
					};
					case '-':{	/*Parse operador anterior*/
						pop(st_char);
						Oper operador = MENOS;
						if (isempty(st_ab)) {error=true;
						}else{
							ABExp* der = top(st_ab); pop(st_ab);
							if (isempty(st_ab)) {error=true;
							}else{
								ABExp* izq = top(st_ab); pop(st_ab);
								ab = crearABExpOper( operador, izq, der);
								// Coloco el resultado en el stack:
								push(st_ab, ab);
							}
						}

						push(st_char, rec[0]);
						break;
					};
					case '/':
					case '*':{
						// Se realizan los calculos con los operadores de menor precedencia:
						while ((!isempty(st_char))&&(top(st_char)!='(') &&
								(top(st_char)!='+')&&(top(st_char)!='-')) {
							char op = top(st_char);
							pop(st_char);

							Oper operador = POR;
							switch (op) {
								case '*':{
										 operador = POR;
										 break;
									 };
								case '/':{
										 operador = DIV;
										 break;
									 };
								default:{
										error = true;
										break;
									};
							}
							if (isempty(st_ab)) {
								error=true;
							} else {
								ABExp* der = top(st_ab); pop(st_ab);
								if (isempty(st_ab)) {
									error=true;
								} else {
									ABExp* izq = top(st_ab); pop(st_ab);
									ab = crearABExpOper( operador, izq, der);
									//Coloco el resultado en el stack:
									push(st_ab, ab);
								}
							}
						}	// end of while.
								
						push(st_char, rec[0]);					
						break;
					};
					default: {
						error = true;
						break;
					};
					}
				}

				rec++;
			} else if ((rec[0]=='*')||(rec[0]=='/')) {
					push(st_char, rec[0]);	
					rec++;
				} else if ((sscanf(rec, "%lf", &val))>0) {
						// Extraer un valor.
						char* str_val = new char[100];
						sscanf(rec, "%[^-^+^*^/^(^)]", str_val);
						int cant_ext = strlen(str_val);
						delete []str_val;

						ab = crearABExpValor(val);
						push(st_ab, ab);

						rec+= cant_ext;
					} else {
						// Extraer variable.
						char* nom_var = new char[100];
						sscanf(rec, "%[^-^+^*^/^(^)]", nom_var);
			
						ab = crearABExpVariable(nom_var);
						push(st_ab, ab);
			
						rec+= strlen(nom_var);
						delete []nom_var;
					}
	}	// for
	
	free (expr_b);
	 
	// Se realizan las operaciones que quedan en el stack:
	while (!isempty(st_char)) {
		char op = top(st_char);
		pop(st_char);

		Oper operador = MAS;
		switch (op) {
			case '+':{
					 operador = MAS;
					 break;
				 };
			case '-':{
					 operador = MENOS;
					 break;
				 };
			case '*':{
					 operador = POR;
					 break;
				 };
			case '/':{
					 operador = DIV;
					 break;
				 };
			default:{ 
					error = true;
					break;
				};
		}
		// Saco los operandos del stack:
		if (isempty(st_ab)) {
			error=true;
		} else {
			ABExp* der = top(st_ab); pop(st_ab);
			if (isempty(st_ab)) {
				error=true;
				destruirABExp(der);
			} else {
				ABExp* izq = top(st_ab); pop(st_ab);
				ab = crearABExpOper( operador, izq, der);
				//Coloco el resultado en el stack:
				push(st_ab, ab);
			}
		}
	}
	
	ABExp* exp = NULL;
	if (isempty(st_ab)) {
		error=true;//Faltan operandos, la sintaxis no es correcta.
	}else{
		exp = top(st_ab);pop(st_ab);
		if (!isempty(st_ab)) {
			error=true;//Faltan operandos, la sintaxis no es correcta.
		}
	}

	destruir_Stack_Char(st_char);
	destruir_Stack_AB(st_ab);
	return exp;
}


